import React, { useState, useEffect } from 'react';
import { LineChart } from 'lucide-react';

function App() {
  const [modelResults, setModelResults] = useState<{
    slope: number;
    intercept: number;
    predictions: number[];
  } | null>(null);

  useEffect(() => {
    // In a real application, you would call the Python model through an API
    // For demonstration, we'll use hardcoded results similar to what the model would produce
    const demoResults = {
      slope: 2.02,
      intercept: 0.08,
      predictions: [2.1, 4.12, 6.14, 8.16, 10.18]
    };
    setModelResults(demoResults);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <div className="flex items-center gap-3 mb-6">
          <LineChart className="w-6 h-6 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-800">Simple Linear Regression Model</h1>
        </div>
        
        {modelResults ? (
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-md">
              <h2 className="text-lg font-semibold text-gray-700 mb-2">Model Parameters</h2>
              <p className="text-gray-600">Slope: {modelResults.slope.toFixed(2)}</p>
              <p className="text-gray-600">Intercept: {modelResults.intercept.toFixed(2)}</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-md">
              <h2 className="text-lg font-semibold text-gray-700 mb-2">Predictions</h2>
              <div className="grid grid-cols-5 gap-2">
                {modelResults.predictions.map((pred, index) => (
                  <div key={index} className="bg-blue-100 p-2 rounded text-center">
                    <div className="text-sm text-gray-600">X: {index + 1}</div>
                    <div className="font-medium text-blue-700">{pred.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-gray-600">Loading model results...</div>
        )}
      </div>
    </div>
  );
}

export default App;