class SimpleLinearRegression:
    def __init__(self):
        self.slope = 0
        self.intercept = 0
    
    def fit(self, X, y):
        # Calculate means
        x_mean = sum(X) / len(X)
        y_mean = sum(y) / len(y)
        
        # Calculate slope
        numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(X, y))
        denominator = sum((x - x_mean) ** 2 for x in X)
        
        self.slope = numerator / denominator
        self.intercept = y_mean - self.slope * x_mean
    
    def predict(self, X):
        return [self.slope * x + self.intercept for x in X]

def train_model():
    # Sample data
    X = [1, 2, 3, 4, 5]
    y = [2.1, 4.0, 6.3, 8.1, 9.9]
    
    # Create and train model
    model = SimpleLinearRegression()
    model.fit(X, y)
    
    # Make predictions
    predictions = model.predict(X)
    
    return {
        'slope': model.slope,
        'intercept': model.intercept,
        'predictions': predictions
    }

if __name__ == "__main__":
    results = train_model()
    print("Model Results:")
    print(f"Slope: {results['slope']:.2f}")
    print(f"Intercept: {results['intercept']:.2f}")
    print("Predictions:", [f"{pred:.2f}" for pred in results['predictions']])